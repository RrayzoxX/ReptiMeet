# ReptiMeet V1 connectée

Cette version connecte le prototype à ton projet Supabase ReptiMeet.

## Test
Ouvre `index.html` dans un navigateur. Pour un vrai déploiement, on passera ensuite par un hébergeur web avec HTTPS.

## Important
La clé utilisée dans ce prototype est une clé Supabase `publishable`, prévue pour être utilisée côté application. Ne mets jamais de clé `sb_secret_...` ou de mot de passe de base de données dans le site.

## Prochaine étape
On ajoutera ensuite le profil complet, les photos Storage, favoris, messagerie et modération.
